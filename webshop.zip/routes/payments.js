// routes/payments.js 
const express = require('express');
const axios = require('axios');
const crypto = require('crypto');
const multer = require('multer');
const path = require('path');
const fs = require('fs').promises;

// Dynamic import สำหรับ Jimp (รองรับ ES modules)
let Jimp = null;
let jsQR = null;

// Initialize libraries
async function initializeLibraries() {
    try {
        // Try different ways to import Jimp
        try {
            Jimp = require('jimp');
        } catch (error1) {
            try {
                const { default: JimpDefault } = await import('jimp');
                Jimp = JimpDefault;
            } catch (error2) {
                console.error('Failed to load Jimp:', error2);
            }
        }

        // Try to import jsQR
        try {
            jsQR = require('jsqr');
        } catch (error) {
            console.error('Failed to load jsQR:', error);
        }
        
        console.log('Libraries initialized - Jimp:', !!Jimp, 'jsQR:', !!jsQR);
    } catch (error) {
        console.error('Error initializing libraries:', error);
    }
}

// Initialize libraries when module loads
initializeLibraries();

const router = express.Router();

// Function to get database pool and other dependencies
let getDbPool, config, requireAuth, logActivity;

try {
    const serverModule = require('../server');
    getDbPool = serverModule.dbPool;
    config = serverModule.config;
    requireAuth = serverModule.requireAuth;
    logActivity = serverModule.logActivity;
} catch (error) {
    console.error('Failed to import server module:', error);
    getDbPool = () => null;
    config = {
        truewallet_api_key: 'fallback-key',
        slip_api_key: 'fallback-key'
    };
    requireAuth = (req, res, next) => next();
    logActivity = () => Promise.resolve();
}

// File upload configuration for slip images
const slipStorage = multer.diskStorage({
    destination: async (req, file, cb) => {
        const uploadPath = 'uploads/slips';
        try {
            await fs.mkdir(uploadPath, { recursive: true });
            cb(null, uploadPath);
        } catch (error) {
            cb(error);
        }
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'slip-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const slipUpload = multer({
    storage: slipStorage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: (req, file, cb) => {
        const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
        if (allowedTypes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only JPEG and PNG images are allowed.'));
        }
    }
});

// Helper function to extract QR code from image
async function extractQRCodeFromImage(imagePath) {
    try {
        console.log('Reading image from:', imagePath);
        
        // Check if libraries are available
        if (!Jimp || !jsQR) {
            throw new Error('Image processing libraries not available. Please install jimp and jsqr packages.');
        }

        // Check if file exists
        const fileExists = await fs.access(imagePath).then(() => true).catch(() => false);
        if (!fileExists) {
            throw new Error('Image file not found');
        }
        
        // Read image with Jimp
        let image;
        try {
            image = await Jimp.read(imagePath);
        } catch (jimpError) {
            console.error('Jimp read error:', jimpError);
            throw new Error('Failed to read image with Jimp: ' + jimpError.message);
        }
        
        // Convert to grayscale for better QR reading
        image.greyscale();
        
        // Get image data for jsQR
        const { width, height } = image.bitmap;
        const data = new Uint8ClampedArray(image.bitmap.data);

        console.log('Image processed - Width:', width, 'Height:', height, 'Data length:', data.length);

        // Try to decode QR code
        let qrCode;
        try {
            qrCode = jsQR(data, width, height);
        } catch (qrError) {
            console.error('jsQR error:', qrError);
            throw new Error('Failed to process QR code: ' + qrError.message);
        }
        
        if (qrCode) {
            console.log('QR Code found:', qrCode.data.substring(0, 50) + '...');
            return qrCode.data;
        }

        // Try with different image preprocessing if first attempt fails
        console.log('QR Code not found, trying with contrast enhancement...');
        
        try {
            // Enhance contrast
            image.contrast(0.5);
            
            const enhancedData = new Uint8ClampedArray(image.bitmap.data);
            const enhancedQr = jsQR(enhancedData, width, height);
            
            if (enhancedQr) {
                console.log('QR Code found after enhancement:', enhancedQr.data.substring(0, 50) + '...');
                return enhancedQr.data;
            }
        } catch (enhanceError) {
            console.error('Enhancement error:', enhanceError);
        }

        // Try with brightness adjustment
        console.log('Trying with brightness adjustment...');
        try {
            image.brightness(0.2);
            const brightData = new Uint8ClampedArray(image.bitmap.data);
            const brightQr = jsQR(brightData, width, height);
            
            if (brightQr) {
                console.log('QR Code found after brightness adjustment');
                return brightQr.data;
            }
        } catch (brightnessError) {
            console.error('Brightness adjustment error:', brightnessError);
        }
        
        throw new Error('QR Code not found in image. Please ensure the slip contains a clear QR code.');
        
    } catch (error) {
        console.error('QR Code extraction error:', error);
        throw new Error('Failed to extract QR Code from image: ' + error.message);
    }
}

// Alternative QR Code extraction using Sharp (fallback method)
async function extractQRCodeUsingSharp(imagePath) {
    try {
        const sharp = require('sharp');
        
        console.log('Trying Sharp method for QR code extraction...');
        
        // Read and process image with Sharp
        const { data, info } = await sharp(imagePath)
            .greyscale()
            .raw()
            .toBuffer({ resolveWithObject: true });

        const imageData = new Uint8ClampedArray(data.length * 4);
        
        // Convert grayscale to RGBA
        for (let i = 0; i < data.length; i++) {
            const pixel = data[i];
            imageData[i * 4] = pixel;     // R
            imageData[i * 4 + 1] = pixel; // G
            imageData[i * 4 + 2] = pixel; // B
            imageData[i * 4 + 3] = 255;   // A
        }

        const qrCode = jsQR(imageData, info.width, info.height);
        
        if (qrCode) {
            console.log('QR Code found using Sharp method');
            return qrCode.data;
        }
        
        throw new Error('QR Code not found with Sharp method');
        
    } catch (error) {
        console.error('Sharp method error:', error);
        throw error;
    }
}

// Manual QR code input fallback
async function requestManualQRCodeInput(paymentRequestId) {
    try {
        const dbPool = getDbPool();
        if (!dbPool) return;

        // Update payment request to request manual input
        await dbPool.execute(`
            UPDATE payment_requests 
            SET notes = 'QR Code could not be read automatically. Manual input required.',
                status = 'pending_manual_input'
            WHERE id = ?
        `, [paymentRequestId]);

        console.log('Payment request marked for manual QR input:', paymentRequestId);
    } catch (error) {
        console.error('Error updating payment for manual input:', error);
    }
}
async function processTrueWalletPayment(giftLink) {
    try {
        const response = await axios.post('https://byshop.me/api/truewallet', {
            keyapi: config.truewallet_api_key,
            phone: process.env.TRUEWALLET_PHONE || '0123456789',
            gift_link: giftLink
        }, {
            timeout: 30000,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });

        return response.data;
    } catch (error) {
        console.error('TrueWallet API error:', error.response?.data || error.message);
        throw new Error('Failed to process TrueWallet payment');
    }
}

// Helper function to verify slip image with API
async function verifySlipImage(qrcodeText, expectedAmount) {
    try {
        console.log('Verifying slip with QR text:', qrcodeText);
        console.log('Expected amount:', expectedAmount);
        
        const response = await axios.post('https://byshop.me/api/check_slip', {
            keyapi: config.slip_api_key,
            qrcode_text: qrcodeText
        }, {
            timeout: 30000,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });

        const result = response.data;
        console.log('API Response:', result);

        return result;
    } catch (error) {
        console.error('Slip verification API error:', error.response?.data || error.message);
        throw new Error('Failed to verify slip with API: ' + (error.response?.data?.massage_th || error.message));
    }
}

// Helper function to update user credits
async function updateUserCredits(userId, amount, transactionType, referenceType, referenceId, description, req) {
    try {
        const dbPool = getDbPool();
        if (!dbPool) {
            throw new Error('Database not available');
        }

        // Get current balance
        const [userResult] = await dbPool.execute('SELECT credits FROM users WHERE id = ?', [userId]);
        if (userResult.length === 0) {
            throw new Error('User not found');
        }

        const currentBalance = parseFloat(userResult[0].credits);
        const newBalance = currentBalance + amount;

        // Update user credits
        await dbPool.execute('UPDATE users SET credits = ? WHERE id = ?', [newBalance, userId]);

        // Record transaction
        await dbPool.execute(`
            INSERT INTO credit_transactions 
            (user_id, transaction_type, amount, balance_before, balance_after, reference_type, reference_id, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [userId, transactionType, amount, currentBalance, newBalance, referenceType, referenceId, description]);

        // Log activity
        await logActivity(userId, 'credits_updated', 'transaction', null, {
            amount,
            transaction_type: transactionType,
            balance_before: currentBalance,
            balance_after: newBalance
        }, req);

        return newBalance;
    } catch (error) {
        console.error('Update credits error:', error);
        throw error;
    }
}

// Helper function to parse amount from string
function parseAmountFromString(amountStr) {
    if (!amountStr) return 0;
    
    // Remove all non-numeric characters except decimal point
    const cleanAmount = amountStr.toString().replace(/[^\d.]/g, '');
    return parseFloat(cleanAmount) || 0;
}

// GET /api/payments/methods - Get Available Payment Methods
router.get('/methods', async (req, res) => {
    try {
        const dbPool = getDbPool();
        if (!dbPool) {
            return res.status(503).json({ 
                success: false, 
                error: 'Database not available' 
            });
        }

        const [methods] = await dbPool.execute(`
            SELECT id, method_name, method_type, instructions, min_amount, max_amount, fees
            FROM payment_methods
            WHERE is_active = 1
            ORDER BY sort_order ASC
        `);

        // Parse JSON fields
        const processedMethods = methods.map(method => ({
            ...method,
            fees: method.fees ? JSON.parse(method.fees) : {}
        }));

        res.json({
            success: true,
            data: processedMethods
        });

    } catch (error) {
        console.error('Get payment methods error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// POST /api/payments/truewallet - Process TrueWallet Payment
router.post('/truewallet', requireAuth, async (req, res) => {
    try {
        const dbPool = getDbPool();
        if (!dbPool) {
            return res.status(503).json({ 
                success: false, 
                error: 'Database not available' 
            });
        }

        const { gift_link } = req.body;
        const userId = req.user.id;

        if (!gift_link) {
            return res.status(400).json({ error: 'Gift link is required' });
        }

        // Validate gift link format
        const giftLinkRegex = /https:\/\/gift\.truemoney\.com\/campaign\/\?v=.+/;
        if (!giftLinkRegex.test(gift_link)) {
            return res.status(400).json({ error: 'Invalid TrueWallet gift link format' });
        }

        // Check for duplicate gift link usage
        const [existingPayment] = await dbPool.execute(`
            SELECT id FROM payment_requests 
            WHERE JSON_EXTRACT(payment_data, '$.gift_link') = ? 
            AND status IN ('completed', 'processing')
        `, [gift_link]);

        if (existingPayment.length > 0) {
            return res.status(400).json({ error: 'This gift link has already been used' });
        }

        // Create payment request
        const [paymentResult] = await dbPool.execute(`
            INSERT INTO payment_requests (user_id, amount, method_type, payment_data, status)
            VALUES (?, 0, 'truewallet', ?, 'processing')
        `, [userId, JSON.stringify({ gift_link })]);

        const paymentRequestId = paymentResult.insertId;

        try {
            // Process TrueWallet payment
            const trueWalletResponse = await processTrueWalletPayment(gift_link);

            if (trueWalletResponse.status === 'success') {
                const amount = parseFloat(trueWalletResponse.amount);

                // Update payment request
                await dbPool.execute(`
                    UPDATE payment_requests 
                    SET amount = ?, status = 'completed', completed_at = NOW(),
                        verification_data = ?
                    WHERE id = ?
                `, [amount, JSON.stringify(trueWalletResponse), paymentRequestId]);

                // Add credits to user
                const newBalance = await updateUserCredits(
                    userId,
                    amount,
                    'deposit',
                    'payment',
                    paymentRequestId,
                    `TrueWallet deposit: ${amount} THB`,
                    req
                );

                res.json({
                    success: true,
                    message: 'Payment processed successfully',
                    data: {
                        amount,
                        new_balance: newBalance,
                        transaction_id: paymentRequestId
                    }
                });

            } else {
                // Update payment request as failed
                await dbPool.execute(`
                    UPDATE payment_requests 
                    SET status = 'failed', verification_data = ?
                    WHERE id = ?
                `, [JSON.stringify(trueWalletResponse), paymentRequestId]);

                res.status(400).json({
                    error: trueWalletResponse.message || 'Payment failed',
                    details: trueWalletResponse
                });
            }

        } catch (apiError) {
            // Update payment request as failed
            await dbPool.execute(`
                UPDATE payment_requests 
                SET status = 'failed', notes = ?
                WHERE id = ?
            `, [apiError.message, paymentRequestId]);

            res.status(500).json({ error: 'Failed to process TrueWallet payment' });
        }

    } catch (error) {
        console.error('TrueWallet payment error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// POST /api/payments/slip-upload - Upload and Verify Bank Transfer Slip (Improved)
router.post('/slip-upload', requireAuth, slipUpload.single('slip_image'), async (req, res) => {
    let imagePath = null;
    
    try {
        const dbPool = getDbPool();
        if (!dbPool) {
            return res.status(503).json({ 
                success: false, 
                error: 'Database not available' 
            });
        }

        const { expected_amount } = req.body;
        const userId = req.user.id;

        console.log('Processing slip upload for user:', userId);
        console.log('Expected amount:', expected_amount);

        if (!req.file) {
            return res.status(400).json({ error: 'Slip image is required' });
        }

        if (!expected_amount) {
            return res.status(400).json({ error: 'Expected amount is required' });
        }

        const expectedAmountNum = parseFloat(expected_amount);
        if (expectedAmountNum < 10 || expectedAmountNum > 50000) {
            return res.status(400).json({ error: 'Invalid amount range (10-50000 THB)' });
        }

        imagePath = req.file.path;
        const slipImageName = req.file.filename;

        console.log('Image uploaded to:', imagePath);

        // Create payment request with expected amount
        const [paymentResult] = await dbPool.execute(`
            INSERT INTO payment_requests (user_id, amount, method_type, payment_data, slip_image, status)
            VALUES (?, ?, 'bank_transfer', ?, ?, 'processing')
        `, [userId, expectedAmountNum, JSON.stringify({ expected_amount: expectedAmountNum }), slipImageName]);

        const paymentRequestId = paymentResult.insertId;

        try {
            // Extract QR code from the slip image with multiple methods
            console.log('Extracting QR code from image...');
            let qrcodeText = null;
            
            try {
                // Method 1: Try Jimp + jsQR
                qrcodeText = await extractQRCodeFromImage(imagePath);
            } catch (jimpError) {
                console.log('Jimp method failed, trying Sharp method...', jimpError.message);
                
                try {
                    // Method 2: Try Sharp + jsQR
                    qrcodeText = await extractQRCodeUsingSharp(imagePath);
                } catch (sharpError) {
                    console.log('Sharp method also failed:', sharpError.message);
                    
                    // Method 3: Request manual input (temporary solution)
                    await requestManualQRCodeInput(paymentRequestId);
                    
                    return res.status(400).json({
                        error: 'ไม่สามารถอ่าน QR Code จากภาพสลิปได้โดยอัตโนมัติ กรุณาติดต่อเจ้าหน้าที่เพื่อดำเนินการด้วยตนเอง',
                        details: {
                            suggestion: 'กรุณาตรวจสอบว่าภาพสลิปชัดเจนและมี QR Code ที่สามารถมองเห็นได้',
                            fallback: 'ระบบจะแจ้งเจ้าหน้าที่เพื่อตรวจสอบด้วยตนเอง',
                            payment_id: paymentRequestId
                        }
                    });
                }
            }
            
            if (!qrcodeText) {
                throw new Error('ไม่สามารถอ่าน QR Code จากภาพสลิปได้ กรุณาตรวจสอบความชัดของภาพ');
            }

            console.log('QR Code extracted successfully, length:', qrcodeText.length);

            // Update payment request with QR code text
            await dbPool.execute(`
                UPDATE payment_requests 
                SET payment_data = ?
                WHERE id = ?
            `, [JSON.stringify({ 
                expected_amount: expectedAmountNum,
                qrcode_text: qrcodeText 
            }), paymentRequestId]);

            // Verify slip with API
            console.log('Verifying slip with API...');
            const slipVerification = await verifySlipImage(qrcodeText, expectedAmountNum);

            // Process API response based on status
            if (slipVerification.status === 1) {
                
                // Check if slip has been used before
                if (slipVerification.check_slip === 1) {
                    await dbPool.execute(`
                        UPDATE payment_requests 
                        SET status = 'failed', verification_data = ?, notes = ?
                        WHERE id = ?
                    `, [JSON.stringify(slipVerification), 'สลิปนี้ถูกใช้ไปแล้ว', paymentRequestId]);

                    return res.status(400).json({ 
                        error: 'สลิปนี้ถูกใช้ไปแล้ว กรุณาใช้สลิปใหม่'
                    });
                }

                // Parse amount from API response
                const actualAmount = parseAmountFromString(slipVerification.amount);
                
                console.log('Actual amount from slip:', actualAmount);
                console.log('Expected amount:', expectedAmountNum);

                // Check if amounts match (allow small difference for float precision)
                const amountDifference = Math.abs(actualAmount - expectedAmountNum);
                if (amountDifference > 0.01) {
                    await dbPool.execute(`
                        UPDATE payment_requests 
                        SET status = 'failed', verification_data = ?, notes = ?
                        WHERE id = ?
                    `, [JSON.stringify(slipVerification), 
                        `จำนวนเงินไม่ตรงกัน คาดหวัง: ${expectedAmountNum} THB, จริง: ${actualAmount} THB`, 
                        paymentRequestId]);

                    return res.status(400).json({ 
                        error: `จำนวนเงินในสลิปไม่ตรงกับที่ระบุ คาดหวัง ${expectedAmountNum} บาท แต่พบ ${actualAmount} บาท`
                    });
                }

                // Get bank account info for additional verification
                const [bankConfig] = await dbPool.execute(`
                    SELECT configuration FROM payment_methods 
                    WHERE method_type = 'bank_transfer' AND is_active = 1
                    LIMIT 1
                `);

                if (bankConfig.length > 0) {
                    const config = JSON.parse(bankConfig[0].configuration);
                    
                    // Verify receiver account (basic check)
                    const receiverAcc = slipVerification.receiver?.acc_no || '';
                    const configAcc = config.account_number || '';
                    
                    // Check if last 4 digits match (for security)
                    if (configAcc && receiverAcc && configAcc.slice(-4) !== receiverAcc.slice(-4)) {
                        await dbPool.execute(`
                            UPDATE payment_requests 
                            SET status = 'failed', notes = 'หมายเลขบัญชีไม่ตรงกัน'
                            WHERE id = ?
                        `, [paymentRequestId]);

                        return res.status(400).json({ 
                            error: 'หมายเลขบัญชีปลายทางไม่ถูกต้อง กรุณาตรวจสอบการโอนเงิน' 
                        });
                    }
                }

                // Check slip timestamp (not older than 24 hours)
                if (slipVerification.slip_timestamp) {
                    const slipTime = new Date(parseInt(slipVerification.slip_timestamp) * 1000);
                    const hoursDiff = (Date.now() - slipTime.getTime()) / (1000 * 60 * 60);

                    if (hoursDiff > 24) {
                        await dbPool.execute(`
                            UPDATE payment_requests 
                            SET status = 'failed', notes = 'สลิปเก่าเกิน 24 ชั่วโมง'
                            WHERE id = ?
                        `, [paymentRequestId]);

                        return res.status(400).json({ 
                            error: 'สลิปเก่าเกินไป กรุณาใช้สลิปที่ไม่เก่าเกิน 24 ชั่วโมง' 
                        });
                    }
                }

                // All checks passed - complete the payment
                await dbPool.execute(`
                    UPDATE payment_requests 
                    SET amount = ?, status = 'completed', completed_at = NOW(),
                        verification_data = ?
                    WHERE id = ?
                `, [actualAmount, JSON.stringify(slipVerification), paymentRequestId]);

                // Add credits to user
                const newBalance = await updateUserCredits(
                    userId,
                    actualAmount,
                    'deposit',
                    'payment',
                    paymentRequestId,
                    `Bank transfer deposit: ${actualAmount} THB (Transaction: ${slipVerification.transactionId || 'N/A'})`,
                    req
                );

                console.log('Payment completed successfully');

                res.json({
                    success: true,
                    message: 'เติมเงินสำเร็จ! ระบบได้ตรวจสอบและอนุมัติการโอนเงินแล้ว',
                    data: {
                        amount: actualAmount,
                        new_balance: newBalance,
                        transaction_id: paymentRequestId,
                        slip_details: {
                            transaction_id: slipVerification.transactionId,
                            slip_time: slipVerification.slip_time,
                            sender_bank: slipVerification.sender?.bank_name,
                            receiver_bank: slipVerification.receiver?.bank_name
                        }
                    }
                });

            } else {
                // Handle API error responses
                let errorMessage = 'ไม่สามารถตรวจสอบสลิปได้';
                
                if (slipVerification.massage_th) {
                    errorMessage = slipVerification.massage_th;
                } else if (slipVerification.massage_en) {
                    // Translate common English messages
                    switch (slipVerification.massage_en) {
                        case 'error list failed.':
                            errorMessage = 'ไม่พบรายการโอนเงิน';
                            break;
                        case 'Insufficient balance':
                            errorMessage = 'ยอดเงินตรวจสอบสลีปไม่เพียงพอ';
                            break;
                        default:
                            errorMessage = slipVerification.massage_en;
                    }
                }

                await dbPool.execute(`
                    UPDATE payment_requests 
                    SET status = 'failed', verification_data = ?, notes = ?
                    WHERE id = ?
                `, [JSON.stringify(slipVerification), errorMessage, paymentRequestId]);

                res.status(400).json({
                    error: errorMessage,
                    details: slipVerification
                });
            }

        } catch (processingError) {
            console.error('Slip processing error:', processingError);
            
            await dbPool.execute(`
                UPDATE payment_requests 
                SET status = 'failed', notes = ?
                WHERE id = ?
            `, [processingError.message, paymentRequestId]);

            res.status(500).json({ 
                error: processingError.message || 'เกิดข้อผิดพลาดในการตรวจสอบสลิป'
            });
        }

    } catch (error) {
        console.error('Slip upload error:', error);
        res.status(500).json({ 
            error: 'เกิดข้อผิดพลาดภายในระบบ กรุณาลองใหม่อีกครั้ง'
        });
    } finally {
        // Clean up uploaded file on error (optional)
        if (imagePath && res.statusCode >= 400) {
            try {
                await fs.unlink(imagePath);
                console.log('Cleaned up uploaded file after error');
            } catch (cleanupError) {
                console.error('Failed to cleanup file:', cleanupError);
            }
        }
    }
});

// GET /api/payments/history - Get Payment History
router.get('/history', requireAuth, async (req, res) => {
    try {
        const dbPool = getDbPool();
        if (!dbPool) {
            return res.status(503).json({ 
                success: false, 
                error: 'Database not available' 
            });
        }

        const { page = 1, limit = 10 } = req.query;
        const userId = req.user.id;
        const offset = (parseInt(page) - 1) * parseInt(limit);

        // Get total count
        const [countResult] = await dbPool.execute(`
            SELECT COUNT(*) as total FROM payment_requests WHERE user_id = ?
        `, [userId]);
        const totalPayments = countResult[0].total;

        // Get payment history
        const [payments] = await dbPool.execute(`
            SELECT 
                id,
                amount,
                method_type,
                status,
                payment_data,
                slip_image,
                verification_data,
                notes,
                created_at,
                completed_at
            FROM payment_requests
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        `, [userId, parseInt(limit), offset]);

        // Parse payment data and add slip URL
        const processedPayments = payments.map(payment => ({
            ...payment,
            payment_data: payment.payment_data ? JSON.parse(payment.payment_data) : null,
            verification_data: payment.verification_data ? JSON.parse(payment.verification_data) : null,
            slip_image: payment.slip_image ? `/uploads/slips/${payment.slip_image}` : null
        }));

        res.json({
            success: true,
            data: {
                payments: processedPayments,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: totalPayments,
                    totalPages: Math.ceil(totalPayments / parseInt(limit))
                }
            }
        });

    } catch (error) {
        console.error('Get payment history error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// GET /api/payments/transactions - Get Credit Transactions
router.get('/transactions', requireAuth, async (req, res) => {
    try {
        const dbPool = getDbPool();
        if (!dbPool) {
            return res.status(503).json({ 
                success: false, 
                error: 'Database not available' 
            });
        }

        const { page = 1, limit = 10, type } = req.query;
        const userId = req.user.id;
        const offset = (parseInt(page) - 1) * parseInt(limit);

        let whereCondition = 'WHERE user_id = ?';
        let queryParams = [userId];

        if (type) {
            whereCondition += ' AND transaction_type = ?';
            queryParams.push(type);
        }

        // Get total count
        const [countResult] = await dbPool.execute(`
            SELECT COUNT(*) as total FROM credit_transactions ${whereCondition}
        `, queryParams);
        const totalTransactions = countResult[0].total;

        // Get transactions
        const [transactions] = await dbPool.execute(`
            SELECT 
                id,
                transaction_type,
                amount,
                balance_before,
                balance_after,
                reference_type,
                reference_id,
                description,
                payment_method,
                created_at
            FROM credit_transactions
            ${whereCondition}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        `, [...queryParams, parseInt(limit), offset]);

        res.json({
            success: true,
            data: {
                transactions,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: totalTransactions,
                    totalPages: Math.ceil(totalTransactions / parseInt(limit))
                }
            }
        });

    } catch (error) {
        console.error('Get transactions error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// GET /api/payments/balance - Get Current Balance
router.get('/balance', requireAuth, async (req, res) => {
    try {
        const dbPool = getDbPool();
        if (!dbPool) {
            return res.status(503).json({ 
                success: false, 
                error: 'Database not available' 
            });
        }

        const userId = req.user.id;

        const [userResult] = await dbPool.execute(`
            SELECT 
                credits,
                total_spent,
                loyalty_points,
                (SELECT COUNT(*) FROM credit_transactions WHERE user_id = ? AND transaction_type = 'deposit') as total_deposits,
                (SELECT COALESCE(SUM(amount), 0) FROM credit_transactions WHERE user_id = ? AND transaction_type = 'deposit') as total_deposited
        `, [userId, userId]);

        if (userResult.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        const balance = userResult[0];

        res.json({
            success: true,
            data: balance
        });

    } catch (error) {
        console.error('Get balance error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;